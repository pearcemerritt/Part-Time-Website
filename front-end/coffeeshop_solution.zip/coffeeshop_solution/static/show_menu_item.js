var showMenuItem = function(item) {
  var xmlh;
  if (window.XMLHttpRequest){
    xmlh = new XMLHttpRequest();
  } else {
    xmlh = new ActiveXObject("Microsoft.XMLHTTTP")
  }

  xmlh.onreadystatechange = function() {
    if (xmlh.readyState == 4) {
      if (xmlh.readyState == 4) {
        if (xmlh.status == 200) {
          data = xmlh.responseText
          jsonResponse = JSON.parse(data)
          item_info = document.getElementById("item_info")
          previous_image = document.getElementById("menu_item_image")

          if (previous_image != null)
            item_info.removeChild(previous_image)

          item_image = document.createElement("img")
          item_image.setAttribute('src', jsonResponse['image'])
          item_image.setAttribute('id', 'menu_item_image')
          item_image.setAttribute('width', '300px')
          item_info.appendChild(item_image)
        }
        else {
          alert("There was an error while retrieving the server time")
        }
      }
    }
  }

  xmlh.open("POST", "/menu_item/" + item, true);
  xmlh.send(JSON.stringify({item: item}));
}